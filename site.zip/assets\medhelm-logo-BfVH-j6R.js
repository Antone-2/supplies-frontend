const o="/assets/medhelm-logo-ConZM3gX.png";export{o as m};
